# ====== HW5 ====== #
1.  Do not change the name of the source file, keep it as "reconstruct.py"
2.  Put your result "output.xyz" under "Results" folder
3.* Do not attach the images or any other file that is already given to you